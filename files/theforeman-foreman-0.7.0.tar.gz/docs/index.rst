.. Foreman Ansible Modules documentation master file, created by
   sphinx-quickstart on Tue Dec 11 10:00:39 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Foreman Ansible Modules's documentation!
===================================================

.. toctree::
   :maxdepth: 2
   :caption: User documentation

   README
   List of all modules <modules/list_of_all_modules>

.. toctree::
   :maxdepth: 2
   :caption: Developer documentation

   developing
   testing
   releasing

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
